ALTER TABLE "session" MODIFY "ip" varchar(41) NOT NULL;
